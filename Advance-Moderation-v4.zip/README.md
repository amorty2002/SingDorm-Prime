# **IMPORTANT**

**Make Sure You Give Credit.. Thank You**

[Join my Support Server](https://discord.gg/aeM2qU49Ej)

## HOW TO SELFHOSt

- download `nodejs` v12 or higher, and `ffmpeg`

- install all dependeces with `npm install` and `npm i @discordjs/opus @k3rn31p4nic/google-translate-api akaneko blague.xyz booru canvacord discord-backup discord-canvas discord-giveaways discord.js-pagination discord.js distube ffmpeg-static figlet mathjs merge-options moment moment-duration-format mongoose ms nekos.life node-fetch num-parse parse-ms quick.db random-puppy request-promise-native simple-youtube-api superagent tinyurl weather-js  `

- start your Bot with `node index.js`

Enjoy ;)

[REPLIT](https://replit.com/@KabirJaipal/A-Advance-Discord-Multi-Purpose-with-Moderation-Music-Fun-et?v=1)

*Yes It Works on REPLIT*

**Discord Server:**
[https://discord.gg/aeM2qU49Ej](https://discord.gg/aeM2qU49Ej)


